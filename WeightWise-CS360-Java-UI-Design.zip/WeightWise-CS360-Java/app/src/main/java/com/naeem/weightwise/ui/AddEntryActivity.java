package com.naeem.weightwise.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.naeem.weightwise.R;

public class AddEntryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);

        EditText etWeight = findViewById(R.id.etWeight);
        EditText etDate   = findViewById(R.id.etDate);
        EditText etGoal   = findViewById(R.id.etGoal);

        Button btnSave   = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        btnSave.setOnClickListener(v -> {
            Intent data = new Intent();
            data.putExtra("weight", etWeight.getText().toString().trim());
            data.putExtra("date",   etDate.getText().toString().trim());
            data.putExtra("goal",   etGoal.getText().toString().trim());
            setResult(RESULT_OK, data);
            finish();
        });

        btnCancel.setOnClickListener(v -> finish());
    }
}
