package com.naeem.weightwise.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.naeem.weightwise.R;
import com.naeem.weightwise.ui.adapters.EntryGridAdapter;
import com.naeem.weightwise.ui.models.Entry;
import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private final List<Entry> items = new ArrayList<>();
    private TextView tvLatest, tvGoal, tvProgress;
    private RecyclerView rv;

    private final ActivityResultLauncher<Intent> addEntryLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    String weight = data.getStringExtra("weight"); // just the number, e.g. 197.9
                    String date   = data.getStringExtra("date");
                    String goal   = data.getStringExtra("goal");

                    if (weight != null && !weight.isEmpty()) {
                        items.add(0, new Entry(System.currentTimeMillis(), "Weight", weight + " lb", date == null ? "" : date));
                        rv.getAdapter().notifyDataSetChanged();
                    }
                    if (goal != null && !goal.isEmpty()) {
                        tvGoal.setText(goal + " lb");
                    }
                    updateSummary();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvLatest   = findViewById(R.id.tvLatestWeight);
        tvGoal     = findViewById(R.id.tvGoalWeight);
        tvProgress = findViewById(R.id.tvProgressDetail);

        rv = findViewById(R.id.rvEntries);
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        EntryGridAdapter adapter = new EntryGridAdapter(items, entry -> {
            items.remove(entry);
            rv.getAdapter().notifyDataSetChanged();
            updateSummary();
        });
        rv.setAdapter(adapter);

        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v ->
                addEntryLauncher.launch(new Intent(this, AddEntryActivity.class))
        );

        Button btnSms = findViewById(R.id.btnSmsSettings);
        btnSms.setOnClickListener(v ->
                startActivity(new Intent(this, SmsSettingsActivity.class))
        );

        updateSummary();
    }

    private void updateSummary() {
        String latest = items.isEmpty() ? "--" : items.get(0).getValue(); // e.g. "197.9 lb"
        tvLatest.setText(latest);

        String goal = tvGoal.getText().toString(); // e.g. "195 lb"
        try {
            double latestVal = latest.equals("--") ? Double.NaN : Double.parseDouble(latest.split(" ")[0]);
            double goalVal   = Double.parseDouble(goal.split(" ")[0]);
            if (!Double.isNaN(latestVal)) {
                double diff = Math.max(0, latestVal - goalVal);
                tvProgress.setText(String.format("%.1f lb to goal", diff));
            } else {
                tvProgress.setText("—");
            }
        } catch (Exception e) {
            tvProgress.setText("—");
        }
    }
}
