package com.naeem.weightwise.ui;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.naeem.weightwise.R;

public class SmsSettingsActivity extends AppCompatActivity {
    private boolean hasSmsPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Notifications");
        }

        TextView tvStatus = findViewById(R.id.tvSmsStatus);
        Button btnEnable = findViewById(R.id.btnEnableSms);
        Button btnDisable = findViewById(R.id.btnDisableSms);
        Button btnBack = findViewById(R.id.btnBackDashboard);

        // Renders text based on permission toggle
        Runnable render = () -> tvStatus.setText(hasSmsPermission
                ? getString(R.string.sms_status_granted)
                : getString(R.string.sms_status_denied));

        btnEnable.setOnClickListener(v -> {
            hasSmsPermission = true;
            render.run();
        });

        btnDisable.setOnClickListener(v -> {
            hasSmsPermission = false;
            render.run();
        });


        btnBack.setOnClickListener(v -> finish());

        render.run();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
