package com.naeem.weightwise.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.naeem.weightwise.R;
import com.naeem.weightwise.ui.models.Entry;
import java.util.List;
import java.util.function.Consumer;

public class EntryGridAdapter extends RecyclerView.Adapter<EntryGridAdapter.VH> {

    private final List<Entry> items;
    private final Consumer<Entry> onDelete;

    public EntryGridAdapter(List<Entry> items, Consumer<Entry> onDelete) {
        this.items = items;
        this.onDelete = onDelete;
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvType, tvValue, tvDate;
        Button btnDelete;
        VH(View v) {
            super(v);
            tvType = v.findViewById(R.id.tvType);
            tvValue = v.findViewById(R.id.tvValue);
            tvDate = v.findViewById(R.id.tvDate);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entry, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Entry e = items.get(position);
        holder.tvType.setText(e.getType());
        holder.tvValue.setText(e.getValue());
        holder.tvDate.setText(e.getDate());
        holder.btnDelete.setOnClickListener(v -> onDelete.accept(e));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}