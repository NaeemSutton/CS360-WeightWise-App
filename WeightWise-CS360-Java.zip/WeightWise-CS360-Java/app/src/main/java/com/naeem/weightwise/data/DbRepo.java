package com.naeem.weightwise.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

// Simple repository for users and weights (CRUD)
public class DbRepo {
    private final DbHelper helper;

    public DbRepo(Context ctx) { helper = new DbHelper(ctx); }

    // ---- Users ----
    public boolean userExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DbHelper.T_USERS, new String[]{DbHelper.COL_USER_ID},
                DbHelper.COL_USERNAME + "=?", new String[]{username}, null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DbHelper.T_USERS, new String[]{DbHelper.COL_USER_ID},
                DbHelper.COL_USERNAME + "=? AND " + DbHelper.COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public long createUser(String username, String password) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.COL_USERNAME, username);
        cv.put(DbHelper.COL_PASSWORD, password);
        return db.insert(DbHelper.T_USERS, null, cv);
    }

    // ---- Weights ----
    public long insertWeight(String date, double weight, Double goalOrNull, String notes) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.COL_WEIGHT_DATE, date);
        cv.put(DbHelper.COL_WEIGHT_VALUE, weight);
        if (goalOrNull != null) cv.put(DbHelper.COL_WEIGHT_GOAL, goalOrNull);
        cv.put(DbHelper.COL_WEIGHT_NOTES, notes);
        return db.insert(DbHelper.T_WEIGHTS, null, cv);
    }

    public int updateWeight(long id, String date, double weight, Double goalOrNull, String notes) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.COL_WEIGHT_DATE, date);
        cv.put(DbHelper.COL_WEIGHT_VALUE, weight);
        if (goalOrNull != null) cv.put(DbHelper.COL_WEIGHT_GOAL, goalOrNull);
        cv.put(DbHelper.COL_WEIGHT_NOTES, notes);
        return db.update(DbHelper.T_WEIGHTS, cv, DbHelper.COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public int deleteWeight(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete(DbHelper.T_WEIGHTS, DbHelper.COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public static class WeightRow {
        public long id;
        public String date;
        public double weight;
        public Double goal; // nullable
        public String notes;
    }

    public List<WeightRow> fetchAllWeightsNewestFirst() {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DbHelper.T_WEIGHTS, null, null, null, null, null,
                DbHelper.COL_WEIGHT_ID + " DESC");
        List<WeightRow> list = new ArrayList<>();
        while (c.moveToNext()) {
            WeightRow r = new WeightRow();
            r.id = c.getLong(c.getColumnIndexOrThrow(DbHelper.COL_WEIGHT_ID));
            r.date = c.getString(c.getColumnIndexOrThrow(DbHelper.COL_WEIGHT_DATE));
            r.weight = c.getDouble(c.getColumnIndexOrThrow(DbHelper.COL_WEIGHT_VALUE));
            int gi = c.getColumnIndexOrThrow(DbHelper.COL_WEIGHT_GOAL);
            r.goal = c.isNull(gi) ? null : c.getDouble(gi);
            r.notes = c.getString(c.getColumnIndexOrThrow(DbHelper.COL_WEIGHT_NOTES));
            list.add(r);
        }
        c.close();
        return list;
    }
}
