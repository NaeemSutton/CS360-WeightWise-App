package com.naeem.weightwise.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.naeem.weightwise.R;
import com.naeem.weightwise.data.DbRepo;

public class AddEntryActivity extends AppCompatActivity {

    private EditText etWeight, etDate, etGoal;   // add etNotes if you use it
    private Button btnSave, btnCancel;

    private DbRepo repo;
    private long editId = -1L;   // >0 means we're editing

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);

        repo = new DbRepo(this);

        etWeight = findViewById(R.id.etWeight);
        etDate   = findViewById(R.id.etDate);
        etGoal   = findViewById(R.id.etGoal);
        btnSave  = findViewById(R.id.btnSave);
        btnCancel= findViewById(R.id.btnCancel);

        // If launched for edit, prefill and mark editId
        String mode = getIntent().getStringExtra("mode");
        if ("edit".equals(mode)) {
            editId = getIntent().getLongExtra("id", -1L);
            etWeight.setText(getIntent().getStringExtra("weight"));
            etDate.setText(getIntent().getStringExtra("date"));
            btnSave.setText("Update");
        }

        btnSave.setOnClickListener(v -> saveOrUpdate());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void saveOrUpdate() {
        String sW = etWeight.getText().toString().trim();
        String sD = etDate.getText().toString().trim();
        String sG = etGoal.getText().toString().trim();

        if (sW.isEmpty() || sD.isEmpty()) {
            Toast.makeText(this, "Enter weight and date", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(sW);
        Double goal = sG.isEmpty() ? null : Double.parseDouble(sG);

        if (editId > 0) {
            // >>> UPDATE <<<
            int rows = repo.updateWeight(editId, sD, weight, goal, null);
            if (rows <= 0) {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                return;
            }
        } else {
            // >>> INSERT <<<
            long id = repo.insertWeight(sD, weight, goal, null);
            if (id <= 0) {
                Toast.makeText(this, "Insert failed", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        setResult(RESULT_OK);
        finish();
    }
}
