package com.naeem.weightwise.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.naeem.weightwise.R;
import com.naeem.weightwise.data.DbRepo;
import com.naeem.weightwise.ui.adapters.EntryGridAdapter;
import com.naeem.weightwise.ui.models.Entry;

import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private final List<Entry> items = new ArrayList<>();
    private TextView tvLatest, tvGoal, tvProgress;
    private RecyclerView rv;
    private DbRepo repo;

    /** Receives result from AddEntryActivity (create or update) */
    private final ActivityResultLauncher<Intent> entryLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> { if (result.getResultCode() == Activity.RESULT_OK) refreshFromDb(); });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        repo = new DbRepo(this);

        tvLatest   = findViewById(R.id.tvLatestWeight);
        tvGoal     = findViewById(R.id.tvGoalWeight);
        tvProgress = findViewById(R.id.tvProgressDetail);

        rv = findViewById(R.id.rvEntries);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        // Adapter with both Delete and Edit handlers
        EntryGridAdapter adapter = new EntryGridAdapter(
                items,
                // DELETE row
                entry -> {
                    repo.deleteWeight(entry.getId());
                    refreshFromDb();
                },
                // EDIT row -> open AddEntryActivity in "edit" mode
                entry -> {
                    try {
                        String valueOnly = entry.getValue().split(" ")[0]; // "198.1 lb" -> "198.1"
                        Intent i = new Intent(this, AddEntryActivity.class);
                        i.putExtra("mode", "edit");
                        i.putExtra("id", entry.getId());
                        i.putExtra("date", entry.getDate());
                        i.putExtra("weight", valueOnly);
                        entryLauncher.launch(i);
                    } catch (Exception e) {
                        Toast.makeText(this, "Unable to open editor", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        rv.setAdapter(adapter);

        // Add new entry
        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> entryLauncher.launch(new Intent(this, AddEntryActivity.class)));

        // Optional: SMS Settings
        Button btnSms = findViewById(R.id.btnSmsSettings);
        if (btnSms != null) btnSms.setOnClickListener(v ->
                startActivity(new Intent(this, SmsSettingsActivity.class)));

        refreshFromDb();
    }

    /** Pulls rows from DB, updates grid and summary cards */
    private void refreshFromDb() {
        items.clear();
        double latest = Double.NaN;
        Double goal = null;

        for (DbRepo.WeightRow r : repo.fetchAllWeightsNewestFirst()) {
            if (Double.isNaN(latest)) latest = r.weight;     // newest first
            if (goal == null && r.goal != null) goal = r.goal;
            items.add(new Entry(r.id, "Weight", String.format("%.1f lb", r.weight), r.date));
        }
        rv.getAdapter().notifyDataSetChanged();

        // Summary cards
        tvLatest.setText(Double.isNaN(latest) ? "--" : String.format("%.1f lb", latest));
        if (goal != null) tvGoal.setText(String.format("%.0f lb", goal));

        if (!Double.isNaN(latest) && goal != null) {
            double diff = latest - goal;
            if (diff <= 0.05) {
                tvProgress.setText("Goal reached!");
            } else {
                tvProgress.setText(String.format("%.1f lb to goal", diff));
            }
        } else {
            tvProgress.setText("—");
        }
    }
}
