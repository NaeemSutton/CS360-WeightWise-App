package com.naeem.weightwise.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.naeem.weightwise.R;
import com.naeem.weightwise.data.DbRepo;

/**
 * Login screen:
 * - Log in by validating username+password in SQLite
 * - Create Account if user doesn't exist (inserts into SQLite)
 * - Remembers the last username via SharedPreferences
 */
public class LoginActivity extends AppCompatActivity {

    private DbRepo repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        repo = new DbRepo(this);

        EditText etUsername = findViewById(R.id.etUsername);
        EditText etPassword = findViewById(R.id.etPassword);
        Button   btnLogin   = findViewById(R.id.btnLogin);
        Button   btnCreate  = findViewById(R.id.btnCreateAccount);

        // Obscure password input (visual dots)
        etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

        // Prefill last username (optional nicety)
        String lastUser = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        if (!lastUser.isEmpty()) etUsername.setText(lastUser);

        btnLogin.setOnClickListener(v -> {
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString().trim();
            if (u.isEmpty() || p.isEmpty()) {
                toast("Enter username and password");
                return;
            }
            if (repo.validateUser(u, p)) {
                rememberUser(u);
                goToDashboard();
            } else {
                toast("Invalid credentials. Create an account if you're new.");
            }
        });

        btnCreate.setOnClickListener(v -> {
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString().trim();
            if (u.isEmpty() || p.isEmpty()) {
                toast("Enter username and password");
                return;
            }
            if (repo.userExists(u)) {
                toast("User already exists. Please log in.");
            } else {
                long id = repo.createUser(u, p);
                if (id > 0) {
                    rememberUser(u);
                    toast("Account created. You're logged in.");
                    goToDashboard();
                } else {
                    toast("Failed to create account. Try again.");
                }
            }
        });
    }

    private void goToDashboard() {
        startActivity(new Intent(this, DashboardActivity.class));
        finish();
    }

    private void rememberUser(String username) {
        SharedPreferences sp = getSharedPreferences("auth", MODE_PRIVATE);
        sp.edit().putString("username", username).apply();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
