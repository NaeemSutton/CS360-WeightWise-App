package com.naeem.weightwise.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.naeem.weightwise.R;

public class SmsSettingsActivity extends AppCompatActivity {
    private static final int REQ_SMS = 1001;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        tvStatus = findViewById(R.id.tvSmsStatus);
        Button btnEnable = findViewById(R.id.btnEnableSms);
        Button btnDisable = findViewById(R.id.btnDisableSms);
        Button btnBack = findViewById(R.id.btnBackDashboard); // if you added it
        Button btnTest = findViewById(R.id.btnSendTestSms);   // optional test button

        renderStatus();

        btnEnable.setOnClickListener(v -> {
            if (!hasPermission()) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
            } else {
                Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
                renderStatus();
            }
        });

        btnDisable.setOnClickListener(v -> {
            Toast.makeText(this, "SMS disabled (permission not used)", Toast.LENGTH_SHORT).show();
            renderStatus();
        });

        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        if (btnTest != null) {
            btnTest.setOnClickListener(v -> {
                if (hasPermission()) {
                    // NOTE: emulator won't send real SMS; this demonstrates the call
                    try {
                        SmsManager sms = SmsManager.getDefault();
                        sms.sendTextMessage("5554", null,
                                "WeightWise: Goal reached! 🎉", null, null);
                        Toast.makeText(this, "Test SMS sent (on real device only)", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Failed to send (emulator limitation)", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Grant SMS permission first", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private boolean hasPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void renderStatus() {
        tvStatus.setText(hasPermission()
                ? getString(R.string.sms_status_granted)
                : getString(R.string.sms_status_denied));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] perms, @NonNull int[] res) {
        super.onRequestPermissionsResult(requestCode, perms, res);
        if (requestCode == REQ_SMS) {
            renderStatus();
        }
    }
}
