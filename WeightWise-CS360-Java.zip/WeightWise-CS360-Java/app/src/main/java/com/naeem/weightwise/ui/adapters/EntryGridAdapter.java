package com.naeem.weightwise.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.naeem.weightwise.R;
import com.naeem.weightwise.ui.models.Entry;

import java.util.List;

public class EntryGridAdapter extends RecyclerView.Adapter<EntryGridAdapter.EntryViewHolder> {

    public interface OnDeleteClickListener { void onDelete(Entry entry); }
    public interface OnEditClickListener   { void onEdit(Entry entry); }

    private final List<Entry> entries;
    private final OnDeleteClickListener deleteListener;
    private final OnEditClickListener editListener;

    public EntryGridAdapter(List<Entry> entries,
                            OnDeleteClickListener deleteListener,
                            OnEditClickListener editListener) {
        this.entries = entries;
        this.deleteListener = deleteListener;
        this.editListener = editListener;
    }

    @NonNull @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_entry, parent, false);
        return new EntryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EntryViewHolder h, int position) {
        Entry e = entries.get(position);
        h.tvType.setText(e.getType());
        h.tvValue.setText(e.getValue());
        h.tvDate.setText(e.getDate());
        h.btnDelete.setOnClickListener(v -> deleteListener.onDelete(e));
        h.btnEdit.setOnClickListener(v -> editListener.onEdit(e));
    }

    @Override public int getItemCount() { return entries.size(); }

    static class EntryViewHolder extends RecyclerView.ViewHolder {
        TextView tvType, tvValue, tvDate;
        Button btnDelete, btnEdit;
        EntryViewHolder(View v) {
            super(v);
            tvType   = v.findViewById(R.id.tvEntryType);
            tvValue  = v.findViewById(R.id.tvEntryValue);
            tvDate   = v.findViewById(R.id.tvEntryDate);
            btnDelete= v.findViewById(R.id.btnDeleteEntry);
            btnEdit  = v.findViewById(R.id.btnEditEntry);
        }
    }
}
