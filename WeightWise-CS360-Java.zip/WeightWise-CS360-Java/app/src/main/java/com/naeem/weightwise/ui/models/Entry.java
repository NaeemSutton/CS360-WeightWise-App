package com.naeem.weightwise.ui.models;

public class Entry {
    private long id;
    private String type;
    private String value;
    private String date;

    public Entry(long id, String type, String value, String date) {
        this.id = id;
        this.type = type;
        this.value = value;
        this.date = date;
    }
    public long getId() { return id; }
    public String getType() { return type; }
    public String getValue() { return value; }
    public String getDate() { return date; }
}